
function RiscoInfo( props ) { 
    let classe = props.nivelRisco.toLowerCase().replace(' ','');
    return(
        <div id="risco" style="display: block;" class="{classe}moderado">
                <p>{props.nivelRisco}Moderado</p>
                <strong>{props.casos}199</strong><span> novos casos por 100 mil habitantes</span>
        </div>
    );
}
